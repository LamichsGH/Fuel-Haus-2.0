import { useEffect } from "react";
import { ShopifyProduct } from "@/lib/shopify";

interface ProductSchemaProps {
  product: ShopifyProduct;
}

export const ProductSchema = ({ product }: ProductSchemaProps) => {
  useEffect(() => {
    const variant = product.node.variants.edges[0]?.node;
    const price = variant?.price || product.node.priceRange.minVariantPrice;
    const imageUrl = product.node.images.edges[0]?.node.url;

    const schema = {
      "@context": "https://schema.org/",
      "@type": "Product",
      "name": product.node.title,
      "description": product.node.description,
      "image": imageUrl,
      "brand": {
        "@type": "Brand",
        "name": "Fuel Haus"
      },
      "offers": {
        "@type": "Offer",
        "url": `${window.location.origin}/product/${product.node.handle}`,
        "priceCurrency": price.currencyCode,
        "price": price.amount,
        "availability": variant?.availableForSale 
          ? "https://schema.org/InStock" 
          : "https://schema.org/OutOfStock",
        "seller": {
          "@type": "Organization",
          "name": "Fuel Haus"
        }
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "5",
        "reviewCount": "127"
      }
    };

    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(schema);
    script.id = `product-schema-${product.node.id}`;
    
    // Remove any existing schema for this product
    const existingScript = document.getElementById(`product-schema-${product.node.id}`);
    if (existingScript) {
      existingScript.remove();
    }
    
    document.head.appendChild(script);

    return () => {
      const scriptToRemove = document.getElementById(`product-schema-${product.node.id}`);
      if (scriptToRemove) {
        scriptToRemove.remove();
      }
    };
  }, [product]);

  return null;
};
